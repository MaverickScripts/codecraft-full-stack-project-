import { NextResponse } from "next/server"

// This is a reference to the same in-memory store from the main route
// In a real app, you would use a database
let members = [
  {
    id: "1",
    name: "Shreyas Chowdhury",
    role: "Developer",
    email: "sc9871@srmist.edu.in",
    contact: "+91 9903300530",
    regNo: "RA2211027010028",
    bio: "Full-stack wizard who turns coffee into code. Specializes in AI-driven solutions and interactive web experiences with a passion for solving complex problems through elegant architecture.",
    profileImage: "/images/tony-stark.png",
  },
  {
    id: "2",
    name: "Sachin Rajesh Pal",
    role: "Scrum Master",
    email: "sp0709@srmist.edu.in",
    contact: "+91 9104019866",
    regNo: "RA2211027010061",
    bio: "Agile evangelist and team catalyst who orchestrates chaos into harmony. Bridges the gap between technical complexity and business value with strategic thinking and exceptional people skills.",
    profileImage: "/images/captain-america.png",
  },
  {
    id: "3",
    name: "Mufeeda O",
    role: "Content Coordinator",
    email: "mo6853@srmist.edu.in",
    contact: "+91 8296723512",
    regNo: "RA2211027010028",
    bio: "Creative storyteller who translates technical jargon into compelling narratives. Blends artistic vision with technical understanding to craft content that educates, engages, and inspires.",
    profileImage: "/images/she-hulk.png",
  },
]

// GET /api/members/[id] - Get a specific member
export async function GET(request: Request, { params }: { params: { id: string } }) {
  const member = members.find((m) => m.id === params.id)

  if (!member) {
    return NextResponse.json({ error: "Member not found" }, { status: 404 })
  }

  return NextResponse.json(member)
}

// PUT /api/members/[id] - Update a member
export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const formData = await request.formData()
    const memberIndex = members.findIndex((m) => m.id === params.id)

    if (memberIndex === -1) {
      return NextResponse.json({ error: "Member not found" }, { status: 404 })
    }

    // Update member data
    const updatedMember = {
      ...members[memberIndex],
      name: (formData.get("name") as string) || members[memberIndex].name,
      role: (formData.get("role") as string) || members[memberIndex].role,
      email: (formData.get("email") as string) || members[memberIndex].email,
      contact: (formData.get("contact") as string) || members[memberIndex].contact,
      regNo: (formData.get("regNo") as string) || members[memberIndex].regNo,
      bio: (formData.get("bio") as string) || members[memberIndex].bio,
    }

    // Update in our "database"
    members[memberIndex] = updatedMember

    return NextResponse.json(updatedMember)
  } catch (error) {
    console.error("Error updating member:", error)
    return NextResponse.json({ error: "Failed to update member" }, { status: 500 })
  }
}

// DELETE /api/members/[id] - Delete a member
export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  const memberIndex = members.findIndex((m) => m.id === params.id)

  if (memberIndex === -1) {
    return NextResponse.json({ error: "Member not found" }, { status: 404 })
  }

  // Remove from our "database"
  const deletedMember = members[memberIndex]
  members = members.filter((m) => m.id !== params.id)

  return NextResponse.json(deletedMember)
}
