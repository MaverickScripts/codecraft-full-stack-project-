import { NextResponse } from "next/server"

// In a real application, you would connect to a database
// This is a simple in-memory store for demonstration
const members = [
  {
    id: "1",
    name: "Shreyas Chowdhury",
    role: "Developer",
    email: "sc9871@srmist.edu.in",
    contact: "+91 9903300530",
    regNo: "RA2211027010028",
    bio: "Full-stack wizard who turns coffee into code. Specializes in AI-driven solutions and interactive web experiences with a passion for solving complex problems through elegant architecture.",
    profileImage: "/images/tony-stark.png",
  },
  {
    id: "2",
    name: "Sachin Rajesh Pal",
    role: "Scrum Master",
    email: "sp0709@srmist.edu.in",
    contact: "+91 9104019866",
    regNo: "RA2211027010061",
    bio: "Agile evangelist and team catalyst who orchestrates chaos into harmony. Bridges the gap between technical complexity and business value with strategic thinking and exceptional people skills.",
    profileImage: "/images/captain-america.png",
  },
  {
    id: "3",
    name: "Mufeeda O",
    role: "Content Coordinator",
    email: "mo6853@srmist.edu.in",
    contact: "+91 8296723512",
    regNo: "RA2211027010028",
    bio: "Creative storyteller who translates technical jargon into compelling narratives. Blends artistic vision with technical understanding to craft content that educates, engages, and inspires.",
    profileImage: "/images/she-hulk.png",
  },
]

// GET /api/members - Get all members
export async function GET() {
  return NextResponse.json(members)
}

// POST /api/members - Create a new member
export async function POST(request: Request) {
  try {
    const formData = await request.formData()

    // In a real app, you would handle file uploads here
    // For example, saving to a storage service like Vercel Blob

    const newMember = {
      id: Date.now().toString(),
      name: formData.get("name") as string,
      role: formData.get("role") as string,
      email: formData.get("email") as string,
      contact: formData.get("contact") as string,
      regNo: formData.get("regNo") as string,
      bio: formData.get("bio") as string,
      profileImage: "/placeholder.svg?height=200&width=200", // Default placeholder
    }

    // Validate required fields
    if (!newMember.name || !newMember.role || !newMember.email || !newMember.regNo) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Add to our "database"
    members.push(newMember)

    return NextResponse.json(newMember, { status: 201 })
  } catch (error) {
    console.error("Error creating member:", error)
    return NextResponse.json({ error: "Failed to create member" }, { status: 500 })
  }
}
