import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Mountain, Code, Users, Zap, Sparkles, Mail, Phone, MapPin } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import Image from "next/image"

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-gradient-to-r from-emerald-600 to-teal-500 text-white shadow-md py-4">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Mountain className="h-8 w-8 text-white" />
            <h1 className="text-2xl font-bold text-white">CodeCraft Crew</h1>
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="/" className="text-white hover:text-emerald-100 transition-colors font-medium">
              Home
            </Link>
            <Link href="/add-member" className="text-white hover:text-emerald-100 transition-colors font-medium">
              Add Member
            </Link>
            <Link href="/members" className="text-white hover:text-emerald-100 transition-colors font-medium">
              View Members
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-b from-emerald-50 to-white py-20 px-4">
          <div className="container mx-auto max-w-5xl">
            <div className="text-center mb-12">
              <h2 className="text-5xl font-bold mb-6 text-gray-800 leading-tight">
                Welcome to <span className="text-emerald-600">CodeCraft Crew</span>
              </h2>
              <p className="text-xl text-gray-600 mb-10 max-w-3xl mx-auto">
                We are a team of passionate student developers building innovative solutions. Our team combines
                technical expertise, leadership, and creative content to deliver exceptional projects.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/add-member">
                  <Button className="w-full sm:w-auto py-6 px-8 text-lg bg-emerald-600 hover:bg-emerald-700 shadow-lg hover:shadow-xl transition-all duration-300">
                    Add Member
                  </Button>
                </Link>
                <Link href="/members">
                  <Button
                    variant="outline"
                    className="w-full sm:w-auto py-6 px-8 text-lg border-emerald-600 text-emerald-600 hover:bg-emerald-50 shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    View Members
                  </Button>
                </Link>
              </div>
            </div>

            {/* Stats Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-16">
              <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow transform hover:-translate-y-1 duration-300">
                <div className="flex items-center justify-center w-16 h-16 bg-emerald-100 rounded-full mb-4 mx-auto">
                  <Code className="h-8 w-8 text-emerald-600" />
                </div>
                <h3 className="text-2xl font-bold text-center mb-2">15+</h3>
                <p className="text-gray-600 text-center">Projects Completed</p>
              </div>

              <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-100 hover:shadow-xl transition-shadow transform hover:-translate-y-1 duration-300">
                <div className="flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4 mx-auto">
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-2xl font-bold text-center mb-2">3+</h3>
                <p className="text-gray-600 text-center">Team Members</p>
              </div>
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-20 px-4 bg-white">
          <div className="container mx-auto max-w-6xl">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4 text-gray-800">Meet Our Core Team</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Our talented team brings diverse skills and perspectives to every project we undertake.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
              <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-emerald-200 group">
                <div className="h-8 bg-gradient-to-r from-emerald-500 to-emerald-600"></div>
                <CardContent className="pt-8 pb-6 px-6 relative">
                  <div className="w-24 h-24 mx-auto rounded-full flex items-center justify-center mb-6 border-4 border-white absolute -top-12 left-1/2 transform -translate-x-1/2 shadow-lg group-hover:scale-110 transition-transform duration-300 overflow-hidden">
                    <Image
                      src="/images/tony-stark.png"
                      alt="Shreyas Chowdhury"
                      width={96}
                      height={96}
                      className="object-cover"
                    />
                  </div>
                  <div className="text-center mt-8">
                    <h4 className="text-xl font-bold mb-1 group-hover:text-emerald-600 transition-colors">
                      Shreyas Chowdhury
                    </h4>
                    <p className="text-emerald-600 font-medium mb-3 flex items-center justify-center gap-1">
                      <Code className="h-4 w-4" /> Developer
                    </p>
                    <p className="text-gray-500 text-sm mb-4">RA2211027010028</p>
                    <p className="text-gray-600 mb-6 line-clamp-3">
                      Full-stack wizard who turns coffee into code. Specializes in AI-driven solutions and interactive
                      web experiences.
                    </p>
                    <Link href="/members/1">
                      <Button
                        variant="outline"
                        className="w-full border-emerald-500 text-emerald-600 hover:bg-emerald-50 hover:text-emerald-700 group-hover:bg-emerald-600 group-hover:text-white group-hover:border-emerald-600 transition-all duration-300"
                      >
                        View Profile
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>

              <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-blue-200 group">
                <div className="h-8 bg-gradient-to-r from-blue-500 to-blue-600"></div>
                <CardContent className="pt-8 pb-6 px-6 relative">
                  <div className="w-24 h-24 mx-auto rounded-full flex items-center justify-center mb-6 border-4 border-white absolute -top-12 left-1/2 transform -translate-x-1/2 shadow-lg group-hover:scale-110 transition-transform duration-300 overflow-hidden">
                    <Image
                      src="/images/captain-america.png"
                      alt="Sachin Rajesh Pal"
                      width={96}
                      height={96}
                      className="object-cover"
                    />
                  </div>
                  <div className="text-center mt-8">
                    <h4 className="text-xl font-bold mb-1 group-hover:text-blue-600 transition-colors">
                      Sachin Rajesh Pal
                    </h4>
                    <p className="text-blue-600 font-medium mb-3 flex items-center justify-center gap-1">
                      <Zap className="h-4 w-4" /> Scrum Master
                    </p>
                    <p className="text-gray-500 text-sm mb-4">RA2211027010061</p>
                    <p className="text-gray-600 mb-6 line-clamp-3">
                      Agile evangelist and team catalyst who orchestrates chaos into harmony. Bridges the gap between
                      technical complexity and business value.
                    </p>
                    <Link href="/members/2">
                      <Button
                        variant="outline"
                        className="w-full border-blue-500 text-blue-600 hover:bg-blue-50 hover:text-blue-700 group-hover:bg-blue-600 group-hover:text-white group-hover:border-blue-600 transition-all duration-300"
                      >
                        View Profile
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>

              <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-purple-200 group">
                <div className="h-8 bg-gradient-to-r from-purple-500 to-purple-600"></div>
                <CardContent className="pt-8 pb-6 px-6 relative">
                  <div className="w-24 h-24 mx-auto rounded-full flex items-center justify-center mb-6 border-4 border-white absolute -top-12 left-1/2 transform -translate-x-1/2 shadow-lg group-hover:scale-110 transition-transform duration-300 overflow-hidden">
                    <Image src="/images/she-hulk.png" alt="Mufeeda O" width={96} height={96} className="object-cover" />
                  </div>
                  <div className="text-center mt-8">
                    <h4 className="text-xl font-bold mb-1 group-hover:text-purple-600 transition-colors">Mufeeda O</h4>
                    <p className="text-purple-600 font-medium mb-3 flex items-center justify-center gap-1">
                      <Sparkles className="h-4 w-4" /> Content Coordinator
                    </p>
                    <p className="text-gray-500 text-sm mb-4">RA2211027010028</p>
                    <p className="text-gray-600 mb-6 line-clamp-3">
                      Creative storyteller who translates technical jargon into compelling narratives. Blends artistic
                      vision with technical understanding.
                    </p>
                    <Link href="/members/3">
                      <Button
                        variant="outline"
                        className="w-full border-purple-500 text-purple-600 hover:bg-purple-50 hover:text-purple-700 group-hover:bg-purple-600 group-hover:text-white group-hover:border-purple-600 transition-all duration-300"
                      >
                        View Profile
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Projects Section */}
        <section className="py-20 px-4 bg-gray-50">
          <div className="container mx-auto max-w-6xl">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4 text-gray-800">Our Latest Projects</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Explore some of our recent work that showcases our team's diverse skills and innovative approach.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-shadow">
                <div className="h-48 bg-gradient-to-r from-emerald-400 to-teal-500 flex items-center justify-center">
                  <Code className="h-16 w-16 text-white" />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">AI-Powered Personal Assistant</h3>
                  <p className="text-gray-600 mb-4">
                    A smart assistant that uses natural language processing to help users manage tasks and information.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <span className="px-3 py-1 bg-emerald-100 text-emerald-700 rounded-full text-xs">AI</span>
                    <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">Python</span>
                    <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-xs">NLP</span>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-shadow">
                <div className="h-48 bg-gradient-to-r from-blue-400 to-indigo-500 flex items-center justify-center">
                  <Users className="h-16 w-16 text-white" />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">Collaborative Code Editor</h3>
                  <p className="text-gray-600 mb-4">
                    Real-time collaborative platform for developers to write and review code together.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <span className="px-3 py-1 bg-emerald-100 text-emerald-700 rounded-full text-xs">React</span>
                    <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">WebSockets</span>
                    <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-xs">Node.js</span>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-shadow">
                <div className="h-48 bg-gradient-to-r from-purple-400 to-pink-500 flex items-center justify-center">
                  <Sparkles className="h-16 w-16 text-white" />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">Visual Data Storytelling</h3>
                  <p className="text-gray-600 mb-4">
                    Interactive data visualization platform that transforms complex data into compelling visual stories.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <span className="px-3 py-1 bg-emerald-100 text-emerald-700 rounded-full text-xs">D3.js</span>
                    <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">SVG</span>
                    <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-xs">UX Design</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-4 bg-gradient-to-r from-emerald-600 to-teal-500 text-white">
          <div className="container mx-auto max-w-4xl text-center">
            <h2 className="text-3xl font-bold mb-6">Ready to Join Our Team?</h2>
            <p className="text-xl mb-8 text-emerald-100">
              We're always looking for talented individuals to join CodeCraft Crew and help us build amazing projects.
            </p>
            <Link href="/add-member">
              <Button className="bg-white text-emerald-600 hover:bg-emerald-50 py-6 px-10 text-lg shadow-lg hover:shadow-xl transition-all duration-300">
                Join the Crew
              </Button>
            </Link>
          </div>
        </section>
      </main>

      <footer className="bg-gray-800 text-white py-12 border-t">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Mountain className="h-6 w-6 text-emerald-400" />
                <h3 className="text-xl font-bold text-emerald-400">CodeCraft Crew</h3>
              </div>
              <p className="text-gray-400 mb-6">
                A team of passionate student developers building innovative solutions with cutting-edge technologies.
              </p>
              <p className="text-gray-400">© {new Date().getFullYear()} CodeCraft Crew. All rights reserved.</p>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/" className="text-gray-400 hover:text-emerald-400 transition-colors">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/members" className="text-gray-400 hover:text-emerald-400 transition-colors">
                    Team Members
                  </Link>
                </li>
                <li>
                  <Link href="/add-member" className="text-gray-400 hover:text-emerald-400 transition-colors">
                    Join the Team
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Contact Us</h4>
              <ul className="space-y-2">
                <li className="flex items-center gap-2 text-gray-400">
                  <Mail className="h-4 w-4" />
                  <span>team@codecraftcrew.com</span>
                </li>
                <li className="flex items-center gap-2 text-gray-400">
                  <Phone className="h-4 w-4" />
                  <span>+91 9903300530</span>
                </li>
                <li className="flex items-center gap-2 text-gray-400">
                  <MapPin className="h-4 w-4" />
                  <span>SRM Institute of Science and Technology, Chennai</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
