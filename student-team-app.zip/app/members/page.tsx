"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Mountain, ArrowLeft, Search, SlidersHorizontal, Mail, Phone, MapPin, Code, Zap, Sparkles } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { motion } from "framer-motion"

// Mock data for team members
const initialMembers = [
  {
    id: "1",
    name: "Shreyas Chowdhury",
    role: "Developer",
    email: "sc9871@srmist.edu.in",
    contact: "+91 9903300530",
    regNo: "RA2211027010028",
    bio: "Full-stack wizard who turns coffee into code. Specializes in AI-driven solutions and interactive web experiences with a passion for solving complex problems through elegant architecture.",
    profileImage: "/images/tony-stark.png",
    skills: ["React", "Node.js", "AI", "TypeScript"],
  },
  {
    id: "2",
    name: "Sachin Rajesh Pal",
    role: "Scrum Master",
    email: "sp0709@srmist.edu.in",
    contact: "+91 9104019866",
    regNo: "RA2211027010061",
    bio: "Agile evangelist and team catalyst who orchestrates chaos into harmony. Bridges the gap between technical complexity and business value with strategic thinking and exceptional people skills.",
    profileImage: "/images/captain-america.png",
    skills: ["Agile", "Leadership", "AI Project Management", "Strategy"],
  },
  {
    id: "3",
    name: "Mufeeda O",
    role: "Content Coordinator",
    email: "mo6853@srmist.edu.in",
    contact: "+91 8296723512",
    regNo: "RA2211027010028",
    bio: "Creative storyteller who translates technical jargon into compelling narratives. Blends artistic vision with technical understanding to craft content that educates, engages, and inspires.",
    profileImage: "/images/she-hulk.png",
    skills: ["Content Creation", "UX Writing", "Technical Documentation", "Visual Design"],
  },
]

export default function Members() {
  const [members, setMembers] = useState(initialMembers)
  const [searchTerm, setSearchTerm] = useState("")
  const [sortBy, setSortBy] = useState("name")
  const [isDarkMode, setIsDarkMode] = useState(false)

  // Filter and sort members
  useEffect(() => {
    let filteredMembers = [...initialMembers]

    // Apply search filter
    if (searchTerm) {
      filteredMembers = filteredMembers.filter(
        (member) =>
          member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          member.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
          member.skills.some((skill) => skill.toLowerCase().includes(searchTerm.toLowerCase())),
      )
    }

    // Apply sorting
    filteredMembers.sort((a, b) => {
      if (sortBy === "name") {
        return a.name.localeCompare(b.name)
      } else if (sortBy === "role") {
        return a.role.localeCompare(b.role)
      }
      return 0
    })

    setMembers(filteredMembers)
  }, [searchTerm, sortBy])

  // Toggle dark mode
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add("dark")
    } else {
      document.documentElement.classList.remove("dark")
    }
  }, [isDarkMode])

  // Get role-specific icon
  const getRoleIcon = (role) => {
    switch (role) {
      case "Developer":
        return <Code className="h-4 w-4" />
      case "Scrum Master":
        return <Zap className="h-4 w-4" />
      case "Content Coordinator":
        return <Sparkles className="h-4 w-4" />
      default:
        return null
    }
  }

  return (
    <div className={`min-h-screen flex flex-col ${isDarkMode ? "dark bg-gray-900 text-white" : "bg-white"}`}>
      <header
        className={`${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-gradient-to-r from-emerald-600 to-teal-500 text-white"} shadow-md py-4`}
      >
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Mountain className="h-8 w-8 text-white" />
            <h1 className="text-2xl font-bold text-white">CodeCraft Crew</h1>
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="/" className="text-white hover:text-emerald-100 transition-colors font-medium">
              Home
            </Link>
            <Link href="/add-member" className="text-white hover:text-emerald-100 transition-colors font-medium">
              Add Member
            </Link>
            <Link href="/members" className="text-white hover:text-emerald-100 transition-colors font-medium">
              View Members
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
            <div className="flex items-center gap-2">
              <Link
                href="/"
                className={`inline-flex items-center ${isDarkMode ? "text-emerald-500 hover:text-emerald-400" : "text-emerald-600 hover:text-emerald-700"}`}
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Home
              </Link>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center space-x-2">
                <Switch id="dark-mode" checked={isDarkMode} onCheckedChange={setIsDarkMode} />
                <Label htmlFor="dark-mode">Dark Mode</Label>
              </div>
            </div>
          </div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <h2 className={`text-3xl font-bold mb-6 ${isDarkMode ? "text-white" : "text-gray-800"}`}>Team Members</h2>

            <div className="flex flex-col md:flex-row gap-4 mb-8">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
                <Input
                  type="text"
                  placeholder="Search by name, role or skill..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className={`pl-10 ${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-white"}`}
                />
              </div>

              <div className="flex items-center gap-2 w-full md:w-48">
                <SlidersHorizontal size={18} className="text-gray-400" />
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className={`${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-white"}`}>
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="name">Sort by Name</SelectItem>
                    <SelectItem value="role">Sort by Role</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </motion.div>

          {members.length === 0 ? (
            <div className={`text-center py-12 ${isDarkMode ? "text-gray-400" : "text-gray-500"}`}>
              <p>No team members found. Try adjusting your search.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {members.map((member, index) => (
                <motion.div
                  key={member.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Link href={`/members/${member.id}`}>
                    <Card
                      className={`h-full overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 ${
                        member.name === "Shreyas Chowdhury"
                          ? "border-emerald-300"
                          : member.name === "Sachin Rajesh Pal"
                            ? "border-blue-300"
                            : "border-purple-300"
                      } ${isDarkMode ? "bg-gray-800" : "bg-white"}`}
                    >
                      <CardContent className="p-0">
                        <div className="aspect-square relative">
                          <Image
                            src={member.profileImage || "/placeholder.svg"}
                            alt={member.name}
                            fill
                            className="object-cover"
                          />
                          <div
                            className={`absolute top-0 left-0 w-full h-1 ${
                              member.role === "Developer"
                                ? "bg-gradient-to-r from-emerald-400 to-emerald-600"
                                : member.role === "Scrum Master"
                                  ? "bg-gradient-to-r from-blue-400 to-blue-600"
                                  : "bg-gradient-to-r from-purple-400 to-purple-600"
                            }`}
                          ></div>
                        </div>
                        <div className="p-6">
                          <h3 className={`text-xl font-bold mb-1 ${isDarkMode ? "text-white" : "text-gray-800"}`}>
                            {member.name}
                          </h3>
                          <p
                            className={`${
                              member.role === "Developer"
                                ? "text-emerald-600"
                                : member.role === "Scrum Master"
                                  ? "text-blue-600"
                                  : "text-purple-600"
                            } font-medium mb-3 flex items-center gap-1`}
                          >
                            {getRoleIcon(member.role)} {member.role}
                          </p>
                          <p className={`text-sm mb-3 ${isDarkMode ? "text-gray-300" : "text-gray-600"}`}>
                            {member.regNo}
                          </p>
                          <p className={`text-sm mb-4 line-clamp-2 ${isDarkMode ? "text-gray-400" : "text-gray-600"}`}>
                            {member.bio}
                          </p>

                          <div className="flex flex-wrap gap-1 mb-4">
                            {member.skills.slice(0, 3).map((skill, i) => (
                              <Badge
                                key={i}
                                variant="outline"
                                className={`${
                                  member.role === "Developer"
                                    ? "border-emerald-200 text-emerald-700"
                                    : member.role === "Scrum Master"
                                      ? "border-blue-200 text-blue-700"
                                      : "border-purple-200 text-purple-700"
                                } ${isDarkMode ? "bg-gray-700" : "bg-white"}`}
                              >
                                {skill}
                              </Badge>
                            ))}
                            {member.skills.length > 3 && (
                              <Badge variant="outline" className="border-gray-200">
                                +{member.skills.length - 3}
                              </Badge>
                            )}
                          </div>

                          <Button
                            variant="outline"
                            className={`w-full ${
                              member.name === "Shreyas Chowdhury"
                                ? "border-emerald-500 text-emerald-600 hover:bg-emerald-50 hover:text-emerald-700"
                                : member.name === "Sachin Rajesh Pal"
                                  ? "border-blue-500 text-blue-600 hover:bg-blue-50 hover:text-blue-700"
                                  : "border-purple-500 text-purple-600 hover:bg-purple-50 hover:text-purple-700"
                            } ${isDarkMode ? "hover:bg-gray-700" : ""}`}
                          >
                            View Details
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </main>

      <footer className={`${isDarkMode ? "bg-gray-800 border-gray-700" : "bg-gray-800 text-white"} py-12 border-t`}>
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Mountain className="h-6 w-6 text-emerald-400" />
                <h3 className="text-xl font-bold text-emerald-400">CodeCraft Crew</h3>
              </div>
              <p className="text-gray-400 mb-6">
                A team of passionate student developers building innovative solutions with cutting-edge technologies.
              </p>
              <p className="text-gray-400">© {new Date().getFullYear()} CodeCraft Crew. All rights reserved.</p>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4 text-white">Quick Links</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/" className="text-gray-400 hover:text-emerald-400 transition-colors">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/members" className="text-gray-400 hover:text-emerald-400 transition-colors">
                    Team Members
                  </Link>
                </li>
                <li>
                  <Link href="/add-member" className="text-gray-400 hover:text-emerald-400 transition-colors">
                    Join the Team
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4 text-white">Contact Us</h4>
              <ul className="space-y-2">
                <li className="flex items-center gap-2 text-gray-400">
                  <Mail className="h-4 w-4" />
                  <span>team@codecraftcrew.com</span>
                </li>
                <li className="flex items-center gap-2 text-gray-400">
                  <Phone className="h-4 w-4" />
                  <span>+91 9903300530</span>
                </li>
                <li className="flex items-center gap-2 text-gray-400">
                  <MapPin className="h-4 w-4" />
                  <span>SRM Institute of Science and Technology, Chennai</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
