"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Mountain,
  ArrowLeft,
  Mail,
  Phone,
  FileText,
  Code,
  Zap,
  Sparkles,
  MapPin,
  Github,
  Linkedin,
  Twitter,
  Award,
  GraduationCap,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { motion } from "framer-motion"

// Mock data for team members
const membersData = [
  {
    id: "1",
    name: "Shreyas Chowdhury",
    role: "Developer",
    email: "sc9871@srmist.edu.in",
    contact: "+91 9903300530",
    regNo: "RA2211027010028",
    bio: "Full-stack wizard who turns coffee into code. Shreyas is the technical backbone of CodeCraft Crew, bringing innovative solutions to life through elegant architecture and clean code. With a keen eye for detail and a passion for emerging technologies, he consistently pushes the boundaries of what's possible in software development. When not coding, he's exploring new AI frameworks or mentoring junior developers.",
    skills: ["React", "Node.js", "MongoDB", "Express", "TypeScript", "Python", "TensorFlow", "AWS", "Docker"],
    projects: [
      "AI-Powered Personal Assistant",
      "Real-time Collaborative Code Editor",
      "Computer Vision Object Recognition System",
      "Blockchain-based Voting Platform",
      "Sentiment Analysis Dashboard",
    ],
    education: [
      {
        degree: "B.Tech in Computer Science",
        institution: "SRM Institute of Science and Technology",
        year: "2019-2023",
      },
      { degree: "Machine Learning Specialization", institution: "Stanford Online", year: "2022" },
    ],
    achievements: [
      "1st Place in SRM Hackathon 2022",
      "Best Technical Innovation Award",
      "Published paper on AI applications in healthcare",
    ],
    socialLinks: {
      github: "https://github.com/shreyaschowdhury",
      linkedin: "https://linkedin.com/in/shreyaschowdhury",
      twitter: "https://twitter.com/shreyaschowdhury",
    },
    profileImage: "/images/tony-stark.png",
  },
  {
    id: "2",
    name: "Sachin Rajesh Pal",
    role: "Scrum Master",
    email: "sp0709@srmist.edu.in",
    contact: "+91 9104019866",
    regNo: "RA2211027010061",
    bio: "Agile evangelist and team catalyst who orchestrates chaos into harmony. Sachin has a remarkable ability to navigate complex project landscapes while keeping the team focused and motivated. His leadership style combines analytical thinking with emotional intelligence, creating an environment where innovation thrives. He's known for turning obstacles into opportunities and maintaining a clear vision even in the most challenging situations.",
    skills: [
      "Agile Methodologies",
      "Project Management",
      "Team Leadership",
      "Risk Management",
      "Strategic Planning",
      "AI Project Coordination",
      "Stakeholder Communication",
      "Data Analytics",
    ],
    projects: [
      "Neural Network Forecasting System",
      "AI Ethics Framework Implementation",
      "Machine Learning Operations Platform",
      "Predictive Analytics Dashboard",
      "Natural Language Processing Service",
    ],
    education: [
      {
        degree: "B.Tech in Computer Science",
        institution: "SRM Institute of Science and Technology",
        year: "2019-2023",
      },
      { degree: "Certified Scrum Master", institution: "Scrum Alliance", year: "2022" },
    ],
    achievements: [
      "Best Project Management Award",
      "Led team to win Regional Innovation Challenge",
      "Recognized for exceptional leadership by SRM",
    ],
    socialLinks: {
      github: "https://github.com/sachinpal",
      linkedin: "https://linkedin.com/in/sachinpal",
      twitter: "https://twitter.com/sachinpal",
    },
    profileImage: "/images/captain-america.png",
  },
  {
    id: "3",
    name: "Mufeeda O",
    role: "Content Coordinator",
    email: "mo6853@srmist.edu.in",
    contact: "+91 8296723512",
    regNo: "RA2211027010028",
    bio: "Creative storyteller who translates technical jargon into compelling narratives. Mufeeda bridges the gap between complex technology and human understanding, crafting content that resonates with diverse audiences. Her unique blend of technical knowledge and artistic sensibility allows her to communicate the team's vision effectively. She excels at finding the perfect balance between information and engagement, making even the most complex concepts accessible and interesting.",
    skills: [
      "Content Creation",
      "Technical Writing",
      "UX Writing",
      "Visual Storytelling",
      "Brand Messaging",
      "Creative Direction",
      "Multimedia Production",
      "Information Architecture",
    ],
    projects: [
      "Interactive Technical Documentation Platform",
      "Visual Data Storytelling Campaign",
      "Augmented Reality User Guide",
      "Developer Experience Content Strategy",
      "Animated Technical Explainer Series",
    ],
    education: [
      {
        degree: "B.Tech in Computer Science",
        institution: "SRM Institute of Science and Technology",
        year: "2019-2023",
      },
      { degree: "Certificate in Digital Content Creation", institution: "Coursera", year: "2021" },
    ],
    achievements: [
      "Best Content Creator Award",
      "Published in Tech Magazine",
      "Led documentation for award-winning project",
    ],
    socialLinks: {
      github: "https://github.com/mufeedao",
      linkedin: "https://linkedin.com/in/mufeedao",
      twitter: "https://twitter.com/mufeedao",
    },
    profileImage: "/images/she-hulk.png",
  },
]

export default function MemberDetails() {
  const params = useParams()
  const router = useRouter()
  const [member, setMember] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // In a real app, you would fetch the member data from an API
    const fetchMember = async () => {
      try {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 500))

        const foundMember = membersData.find((m) => m.id === params.id)

        if (foundMember) {
          setMember(foundMember)
        } else {
          // Member not found, redirect to members page
          router.push("/members")
        }
      } catch (error) {
        console.error("Error fetching member:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchMember()
  }, [params.id, router])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600"></div>
          <p className="mt-4 text-gray-500">Loading member details...</p>
        </div>
      </div>
    )
  }

  if (!member) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-500">Member not found</p>
          <Link href="/members">
            <Button className="mt-4">Back to Members</Button>
          </Link>
        </div>
      </div>
    )
  }

  // Determine color theme based on role
  const getColorTheme = () => {
    switch (member.role) {
      case "Developer":
        return {
          primary: "text-emerald-600",
          bg: "bg-emerald-50",
          border: "border-emerald-200",
          button: "bg-emerald-600 hover:bg-emerald-700",
          gradient: "from-emerald-500 to-emerald-600",
          light: "bg-emerald-100",
          icon: <Code className="h-5 w-5" />,
        }
      case "Scrum Master":
        return {
          primary: "text-blue-600",
          bg: "bg-blue-50",
          border: "border-blue-200",
          button: "bg-blue-600 hover:bg-blue-700",
          gradient: "from-blue-500 to-blue-600",
          light: "bg-blue-100",
          icon: <Zap className="h-5 w-5" />,
        }
      case "Content Coordinator":
        return {
          primary: "text-purple-600",
          bg: "bg-purple-50",
          border: "border-purple-200",
          button: "bg-purple-600 hover:bg-purple-700",
          gradient: "from-purple-500 to-purple-600",
          light: "bg-purple-100",
          icon: <Sparkles className="h-5 w-5" />,
        }
      default:
        return {
          primary: "text-gray-600",
          bg: "bg-gray-50",
          border: "border-gray-200",
          button: "bg-gray-600 hover:bg-gray-700",
          gradient: "from-gray-500 to-gray-600",
          light: "bg-gray-100",
          icon: null,
        }
    }
  }

  const colors = getColorTheme()

  return (
    <div className="min-h-screen flex flex-col">
      <header className={`bg-gradient-to-r ${colors.gradient} text-white shadow-md py-4`}>
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Mountain className="h-8 w-8 text-white" />
            <h1 className="text-2xl font-bold text-white">CodeCraft Crew</h1>
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="/" className="text-white hover:text-emerald-100 transition-colors font-medium">
              Home
            </Link>
            <Link href="/add-member" className="text-white hover:text-emerald-100 transition-colors font-medium">
              Add Member
            </Link>
            <Link href="/members" className="text-white hover:text-emerald-100 transition-colors font-medium">
              View Members
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-12">
        <div className="max-w-5xl mx-auto">
          <Link href="/members" className="inline-flex items-center text-emerald-600 hover:text-emerald-700 mb-6">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Members
          </Link>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div
              className="md:col-span-1"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Card className="overflow-hidden shadow-lg border-t-4 border-t-emerald-500">
                <div className="aspect-square relative">
                  <Image
                    src={member.profileImage || "/placeholder.svg"}
                    alt={member.name}
                    fill
                    className="object-cover"
                  />
                  <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${colors.gradient}`}></div>
                </div>
                <CardContent className="p-6">
                  <div className="flex items-center gap-2 mb-2">
                    <div className={`p-2 rounded-full ${colors.light}`}>{colors.icon}</div>
                    <h2 className="text-2xl font-bold">{member.name}</h2>
                  </div>
                  <p className={`${colors.primary} font-medium mb-4 flex items-center gap-1`}>
                    {colors.icon} {member.role}
                  </p>
                  <p className="text-sm text-gray-500 mb-6">{member.regNo}</p>

                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-gray-400" />
                      <span className="text-sm">{member.email}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-gray-400" />
                      <span className="text-sm">{member.contact}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-gray-400" />
                      <span className="text-sm">SRM Institute of Science and Technology</span>
                    </div>
                  </div>

                  <div className="flex justify-between mt-6 pt-6 border-t">
                    <a
                      href={member.socialLinks.github}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-500 hover:text-gray-700"
                    >
                      <Github className="h-5 w-5" />
                    </a>
                    <a
                      href={member.socialLinks.linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-500 hover:text-gray-700"
                    >
                      <Linkedin className="h-5 w-5" />
                    </a>
                    <a
                      href={member.socialLinks.twitter}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-500 hover:text-gray-700"
                    >
                      <Twitter className="h-5 w-5" />
                    </a>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              className="md:col-span-2 space-y-6"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Tabs defaultValue="about">
                <TabsList className="mb-4">
                  <TabsTrigger value="about">About</TabsTrigger>
                  <TabsTrigger value="skills">Skills</TabsTrigger>
                  <TabsTrigger value="projects">Projects</TabsTrigger>
                  <TabsTrigger value="education">Education</TabsTrigger>
                </TabsList>

                <TabsContent value="about" className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>About {member.name.split(" ")[0]}</CardTitle>
                      <CardDescription>Bio and personal information</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-700 leading-relaxed">{member.bio}</p>

                      <div className="mt-6 pt-6 border-t">
                        <h4 className="font-semibold mb-3">Achievements</h4>
                        <ul className="space-y-2">
                          {member.achievements.map((achievement, index) => (
                            <li key={index} className="flex items-start gap-2">
                              <Award className="h-5 w-5 text-yellow-500 mt-0.5" />
                              <span>{achievement}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="skills" className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Skills & Expertise</CardTitle>
                      <CardDescription>Technical and professional capabilities</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2">
                        {member.skills.map((skill, index) => (
                          <Badge
                            key={index}
                            className={`px-3 py-1 text-sm ${colors.primary} ${colors.bg} ${colors.border} border`}
                          >
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="projects" className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Projects</CardTitle>
                      <CardDescription>Recent work and contributions</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-4">
                        {member.projects.map((project, index) => (
                          <li
                            key={index}
                            className="flex items-start gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors"
                          >
                            <FileText className={`h-5 w-5 ${colors.primary} mt-0.5`} />
                            <div>
                              <h4 className="font-medium">{project}</h4>
                              <p className="text-sm text-gray-500">
                                {index === 0 ? "Lead Developer" : index === 1 ? "Project Coordinator" : "Contributor"}
                              </p>
                            </div>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="education" className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Education & Certifications</CardTitle>
                      <CardDescription>Academic background and professional development</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-6">
                        {member.education.map((edu, index) => (
                          <li key={index} className="flex items-start gap-3">
                            <div className={`p-2 rounded-full ${colors.bg} mt-0.5`}>
                              <GraduationCap className={`h-5 w-5 ${colors.primary}`} />
                            </div>
                            <div>
                              <h4 className="font-medium">{edu.degree}</h4>
                              <p className="text-sm text-gray-600">{edu.institution}</p>
                              <p className="text-sm text-gray-500">{edu.year}</p>
                            </div>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>

              <div className="flex justify-end">
                <Button className={`${colors.button} shadow-lg hover:shadow-xl transition-all duration-300`}>
                  Contact {member.name.split(" ")[0]}
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      </main>

      <footer className="bg-gray-800 text-white py-12 border-t">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Mountain className="h-6 w-6 text-emerald-400" />
                <h3 className="text-xl font-bold text-emerald-400">CodeCraft Crew</h3>
              </div>
              <p className="text-gray-400 mb-6">
                A team of passionate student developers building innovative solutions with cutting-edge technologies.
              </p>
              <p className="text-gray-400">© {new Date().getFullYear()} CodeCraft Crew. All rights reserved.</p>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/" className="text-gray-400 hover:text-emerald-400 transition-colors">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/members" className="text-gray-400 hover:text-emerald-400 transition-colors">
                    Team Members
                  </Link>
                </li>
                <li>
                  <Link href="/add-member" className="text-gray-400 hover:text-emerald-400 transition-colors">
                    Join the Team
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Contact Us</h4>
              <ul className="space-y-2">
                <li className="flex items-center gap-2 text-gray-400">
                  <Mail className="h-4 w-4" />
                  <span>team@codecraftcrew.com</span>
                </li>
                <li className="flex items-center gap-2 text-gray-400">
                  <Phone className="h-4 w-4" />
                  <span>+91 9903300530</span>
                </li>
                <li className="flex items-center gap-2 text-gray-400">
                  <MapPin className="h-4 w-4" />
                  <span>SRM Institute of Science and Technology, Chennai</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
