"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { toast } from "@/components/ui/use-toast"
import {
  Mountain,
  ArrowLeft,
  Upload,
  Mail,
  Phone,
  FileText,
  User,
  Code,
  Zap,
  Sparkles,
  MapPin,
  PenTool,
  CheckCircle,
} from "lucide-react"
import { motion } from "framer-motion"

export default function AddMember() {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    role: "",
    email: "",
    contact: "",
    regNo: "",
    bio: "",
    profileImage: null as File | null,
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (value: string) => {
    setFormData((prev) => ({ ...prev, role: value }))
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFormData((prev) => ({ ...prev, profileImage: e.target.files![0] }))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // In a real app, you would use FormData to handle file uploads
      const data = new FormData()
      Object.entries(formData).forEach(([key, value]) => {
        if (value !== null) {
          data.append(key, value as string | Blob)
        }
      })

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // In a real app, you would make an actual API call:
      // const response = await fetch('/api/members', {
      //   method: 'POST',
      //   body: data,
      // })

      toast({
        title: "Success!",
        description: "Team member has been added successfully.",
      })

      router.push("/members")
    } catch (error) {
      console.error("Error adding member:", error)
      toast({
        title: "Error",
        description: "Failed to add team member. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  // Get role-specific icon
  const getRoleIcon = (role: string) => {
    switch (role) {
      case "Developer":
        return <Code className="h-5 w-5 text-emerald-600" />
      case "Scrum Master":
        return <Zap className="h-5 w-5 text-blue-600" />
      case "Content Coordinator":
        return <Sparkles className="h-5 w-5 text-purple-600" />
      default:
        return <User className="h-5 w-5 text-gray-600" />
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-gradient-to-r from-emerald-600 to-teal-500 text-white shadow-md py-4">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Mountain className="h-8 w-8 text-white" />
            <h1 className="text-2xl font-bold text-white">CodeCraft Crew</h1>
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="/" className="text-white hover:text-emerald-100 transition-colors font-medium">
              Home
            </Link>
            <Link href="/add-member" className="text-white hover:text-emerald-100 transition-colors font-medium">
              Add Member
            </Link>
            <Link href="/members" className="text-white hover:text-emerald-100 transition-colors font-medium">
              View Members
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-12 bg-gray-50">
        <div className="max-w-2xl mx-auto">
          <Link href="/" className="inline-flex items-center text-emerald-600 hover:text-emerald-700 mb-6">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <Card className="shadow-lg border-t-4 border-emerald-500">
              <CardHeader className="bg-gradient-to-r from-emerald-50 to-white">
                <CardTitle className="text-2xl">Add Team Member</CardTitle>
                <CardDescription>Fill in the details to add a new member to the CodeCraft Crew.</CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="text-sm font-medium flex items-center gap-2">
                      <User className="h-4 w-4 text-gray-500" /> Full Name
                    </Label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Enter full name"
                      className="border-gray-300 focus:border-emerald-500 focus:ring-emerald-500"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="role" className="text-sm font-medium flex items-center gap-2">
                      <FileText className="h-4 w-4 text-gray-500" /> Role
                    </Label>
                    <Select onValueChange={handleSelectChange} required>
                      <SelectTrigger className="border-gray-300 focus:border-emerald-500 focus:ring-emerald-500">
                        <SelectValue placeholder="Select a role" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Developer" className="flex items-center gap-2">
                          <div className="flex items-center gap-2">
                            <Code className="h-4 w-4 text-emerald-600" /> Developer
                          </div>
                        </SelectItem>
                        <SelectItem value="Scrum Master">
                          <div className="flex items-center gap-2">
                            <Zap className="h-4 w-4 text-blue-600" /> Scrum Master
                          </div>
                        </SelectItem>
                        <SelectItem value="Content Coordinator">
                          <div className="flex items-center gap-2">
                            <Sparkles className="h-4 w-4 text-purple-600" /> Content Coordinator
                          </div>
                        </SelectItem>
                        <SelectItem value="Designer">
                          <div className="flex items-center gap-2">
                            <PenTool className="h-4 w-4 text-pink-600" /> Designer
                          </div>
                        </SelectItem>
                        <SelectItem value="QA Engineer">
                          <div className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-amber-600" /> QA Engineer
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-sm font-medium flex items-center gap-2">
                        <Mail className="h-4 w-4 text-gray-500" /> Email
                      </Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="email@example.com"
                        className="border-gray-300 focus:border-emerald-500 focus:ring-emerald-500"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="contact" className="text-sm font-medium flex items-center gap-2">
                        <Phone className="h-4 w-4 text-gray-500" /> Contact Number
                      </Label>
                      <Input
                        id="contact"
                        name="contact"
                        value={formData.contact}
                        onChange={handleChange}
                        placeholder="Enter contact number"
                        className="border-gray-300 focus:border-emerald-500 focus:ring-emerald-500"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="regNo" className="text-sm font-medium flex items-center gap-2">
                      <FileText className="h-4 w-4 text-gray-500" /> Registration Number
                    </Label>
                    <Input
                      id="regNo"
                      name="regNo"
                      value={formData.regNo}
                      onChange={handleChange}
                      placeholder="e.g. RA2211027010028"
                      className="border-gray-300 focus:border-emerald-500 focus:ring-emerald-500"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bio" className="text-sm font-medium flex items-center gap-2">
                      <FileText className="h-4 w-4 text-gray-500" /> Bio / Additional Information
                    </Label>
                    <Textarea
                      id="bio"
                      name="bio"
                      value={formData.bio}
                      onChange={handleChange}
                      placeholder="Brief description about the team member"
                      rows={4}
                      className="border-gray-300 focus:border-emerald-500 focus:ring-emerald-500"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="profileImage" className="text-sm font-medium flex items-center gap-2">
                      <Upload className="h-4 w-4 text-gray-500" /> Profile Image
                    </Label>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-emerald-500 transition-colors">
                      <Input
                        id="profileImage"
                        name="profileImage"
                        type="file"
                        accept="image/*"
                        onChange={handleFileChange}
                        className="hidden"
                      />
                      <label htmlFor="profileImage" className="cursor-pointer flex flex-col items-center">
                        <Upload className="h-10 w-10 text-gray-400 mb-2" />
                        <span className="text-sm font-medium text-gray-700">Click to upload a profile picture</span>
                        <span className="text-xs text-gray-500 mt-1">SVG, PNG, JPG or GIF (Max. 2MB)</span>
                      </label>
                    </div>
                  </div>

                  <CardFooter className="px-0 pt-6">
                    <Button
                      type="submit"
                      className="w-full bg-emerald-600 hover:bg-emerald-700 shadow-lg hover:shadow-xl transition-all duration-300 py-6"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? "Adding Member..." : "Add Team Member"}
                    </Button>
                  </CardFooter>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </main>

      <footer className="bg-gray-800 text-white py-12 border-t">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Mountain className="h-6 w-6 text-emerald-400" />
                <h3 className="text-xl font-bold text-emerald-400">CodeCraft Crew</h3>
              </div>
              <p className="text-gray-400 mb-6">
                A team of passionate student developers building innovative solutions with cutting-edge technologies.
              </p>
              <p className="text-gray-400">© {new Date().getFullYear()} CodeCraft Crew. All rights reserved.</p>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/" className="text-gray-400 hover:text-emerald-400 transition-colors">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/members" className="text-gray-400 hover:text-emerald-400 transition-colors">
                    Team Members
                  </Link>
                </li>
                <li>
                  <Link href="/add-member" className="text-gray-400 hover:text-emerald-400 transition-colors">
                    Join the Team
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Contact Us</h4>
              <ul className="space-y-2">
                <li className="flex items-center gap-2 text-gray-400">
                  <Mail className="h-4 w-4" />
                  <span>team@codecraftcrew.com</span>
                </li>
                <li className="flex items-center gap-2 text-gray-400">
                  <Phone className="h-4 w-4" />
                  <span>+91 9903300530</span>
                </li>
                <li className="flex items-center gap-2 text-gray-400">
                  <MapPin className="h-4 w-4" />
                  <span>SRM Institute of Science and Technology, Chennai</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
